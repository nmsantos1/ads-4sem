//Faça um algoritmo que escreva os números de 1 até 50.
package lista01_01;


public class Lista01_01 {

    public static void main(String[] args) {
        
        System.out.println("Numeros de 1 a 50:");
        for(int i = 1; i < 51; i++){
            System.out.print(i+" ");
        }
        
    }
    
}
