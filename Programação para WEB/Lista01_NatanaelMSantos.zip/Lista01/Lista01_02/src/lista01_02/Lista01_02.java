//Desenvolva um programa que mostre em ordem decrescente os números de 10 à 1
package lista01_02;


public class Lista01_02 {

    public static void main(String[] args) {
        
        System.out.println("Numeros de 10 a 1:");
        for(int i = 10; i > 0; i--){
            System.out.print(i+" ");
        }
        
    }
    
}
