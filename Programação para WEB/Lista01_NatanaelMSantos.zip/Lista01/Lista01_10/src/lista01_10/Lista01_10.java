//Faça um programa que mostre os números de 30 até 70 em ordem decrescente
package lista01_10;

public class Lista01_10 {

    public static void main(String[] args) {
        
        for(int i = 70; i > 29; i--){
            System.out.println(i);
        }
    }
    
}